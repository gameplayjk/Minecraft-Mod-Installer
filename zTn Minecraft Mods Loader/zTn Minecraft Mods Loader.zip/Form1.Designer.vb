﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TwitchTheme1 = New zTn_Minecraft_Mods_Loader.TwitchTheme()
        Me.AdvantiumCheck1 = New zTn_Minecraft_Mods_Loader.AdvantiumCheck()
        Me.ChromeTabcontrol1 = New zTn_Minecraft_Mods_Loader.ChromeTabcontrol()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TwitchGroupBox2 = New zTn_Minecraft_Mods_Loader.TwitchGroupBox()
        Me.TwitchLabel2 = New zTn_Minecraft_Mods_Loader.TwitchLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TwitchGroupBox3 = New zTn_Minecraft_Mods_Loader.TwitchGroupBox()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TwitchGroupBox1 = New zTn_Minecraft_Mods_Loader.TwitchGroupBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.TwitchBigButton2 = New zTn_Minecraft_Mods_Loader.TwitchBigButton()
        Me.TwitchBigButton1 = New zTn_Minecraft_Mods_Loader.TwitchBigButton()
        Me.TwitchLabel1 = New zTn_Minecraft_Mods_Loader.TwitchLabel()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.TwitchTheme1.SuspendLayout()
        Me.ChromeTabcontrol1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TwitchGroupBox2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.TwitchGroupBox3.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TwitchGroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 500
        '
        'TwitchTheme1
        '
        Me.TwitchTheme1.BackColor = System.Drawing.Color.White
        Me.TwitchTheme1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.TwitchTheme1.Controls.Add(Me.AdvantiumCheck1)
        Me.TwitchTheme1.Controls.Add(Me.ChromeTabcontrol1)
        Me.TwitchTheme1.Customization = "AAD//w=="
        Me.TwitchTheme1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TwitchTheme1.Fill = True
        Me.TwitchTheme1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.TwitchTheme1.Image = Nothing
        Me.TwitchTheme1.Location = New System.Drawing.Point(0, 0)
        Me.TwitchTheme1.MaximumSize = New System.Drawing.Size(757, 498)
        Me.TwitchTheme1.MinimumSize = New System.Drawing.Size(757, 498)
        Me.TwitchTheme1.Movable = True
        Me.TwitchTheme1.Name = "TwitchTheme1"
        Me.TwitchTheme1.NoRounding = False
        Me.TwitchTheme1.Sizable = True
        Me.TwitchTheme1.Size = New System.Drawing.Size(757, 498)
        Me.TwitchTheme1.SmartBounds = True
        Me.TwitchTheme1.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TwitchTheme1.TabIndex = 0
        Me.TwitchTheme1.Text = "TwitchTheme1"
        Me.TwitchTheme1.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.TwitchTheme1.Transparent = False
        '
        'AdvantiumCheck1
        '
        Me.AdvantiumCheck1.CheckedState = False
        Me.AdvantiumCheck1.Customization = "GRkZ/zs7O/8A/Hz/8MCE/wD8fP8A/Hz/TfIq/yMjI/8jIyP/"
        Me.AdvantiumCheck1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.AdvantiumCheck1.Image = Nothing
        Me.AdvantiumCheck1.Location = New System.Drawing.Point(735, 6)
        Me.AdvantiumCheck1.MaximumSize = New System.Drawing.Size(600, 16)
        Me.AdvantiumCheck1.MinimumSize = New System.Drawing.Size(16, 16)
        Me.AdvantiumCheck1.Name = "AdvantiumCheck1"
        Me.AdvantiumCheck1.NoRounding = False
        Me.AdvantiumCheck1.Size = New System.Drawing.Size(16, 16)
        Me.AdvantiumCheck1.TabIndex = 1
        Me.AdvantiumCheck1.Transparent = False
        '
        'ChromeTabcontrol1
        '
        Me.ChromeTabcontrol1.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.ChromeTabcontrol1.Controls.Add(Me.TabPage1)
        Me.ChromeTabcontrol1.Controls.Add(Me.TabPage2)
        Me.ChromeTabcontrol1.Controls.Add(Me.TabPage3)
        Me.ChromeTabcontrol1.Controls.Add(Me.TabPage4)
        Me.ChromeTabcontrol1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ChromeTabcontrol1.ItemSize = New System.Drawing.Size(30, 115)
        Me.ChromeTabcontrol1.Location = New System.Drawing.Point(0, 30)
        Me.ChromeTabcontrol1.Multiline = True
        Me.ChromeTabcontrol1.Name = "ChromeTabcontrol1"
        Me.ChromeTabcontrol1.SelectedIndex = 0
        Me.ChromeTabcontrol1.ShowOuterBorders = False
        Me.ChromeTabcontrol1.Size = New System.Drawing.Size(757, 468)
        Me.ChromeTabcontrol1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.ChromeTabcontrol1.SquareColor = System.Drawing.Color.Purple
        Me.ChromeTabcontrol1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.White
        Me.TabPage1.Controls.Add(Me.TwitchGroupBox2)
        Me.TabPage1.Location = New System.Drawing.Point(119, 4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(634, 460)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Inìcio"
        '
        'TwitchGroupBox2
        '
        Me.TwitchGroupBox2.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.TwitchGroupBox2.Colors = New zTn_Minecraft_Mods_Loader.Bloom(-1) {}
        Me.TwitchGroupBox2.Controls.Add(Me.TwitchLabel2)
        Me.TwitchGroupBox2.Controls.Add(Me.PictureBox1)
        Me.TwitchGroupBox2.Cursor = System.Windows.Forms.Cursors.Default
        Me.TwitchGroupBox2.Customization = ""
        Me.TwitchGroupBox2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TwitchGroupBox2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.TwitchGroupBox2.Image = Nothing
        Me.TwitchGroupBox2.Location = New System.Drawing.Point(3, 3)
        Me.TwitchGroupBox2.Movable = True
        Me.TwitchGroupBox2.Name = "TwitchGroupBox2"
        Me.TwitchGroupBox2.NoRounding = False
        Me.TwitchGroupBox2.Sizable = True
        Me.TwitchGroupBox2.Size = New System.Drawing.Size(628, 454)
        Me.TwitchGroupBox2.SmartBounds = True
        Me.TwitchGroupBox2.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.TwitchGroupBox2.TabIndex = 0
        Me.TwitchGroupBox2.Text = "Melhores Mods / Novos Mods"
        Me.TwitchGroupBox2.TransparencyKey = System.Drawing.Color.Empty
        Me.TwitchGroupBox2.Transparent = False
        '
        'TwitchLabel2
        '
        Me.TwitchLabel2.AutoSize = True
        Me.TwitchLabel2.BackColor = System.Drawing.Color.Transparent
        Me.TwitchLabel2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.TwitchLabel2.Location = New System.Drawing.Point(268, 44)
        Me.TwitchLabel2.Name = "TwitchLabel2"
        Me.TwitchLabel2.Size = New System.Drawing.Size(121, 13)
        Me.TwitchLabel2.TabIndex = 2
        Me.TwitchLabel2.Text = "Mods Mais Baixados"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Location = New System.Drawing.Point(88, 60)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(472, 257)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.White
        Me.TabPage2.Controls.Add(Me.TwitchGroupBox3)
        Me.TabPage2.Location = New System.Drawing.Point(119, 4)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(634, 460)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Mods"
        '
        'TwitchGroupBox3
        '
        Me.TwitchGroupBox3.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.TwitchGroupBox3.Colors = New zTn_Minecraft_Mods_Loader.Bloom(-1) {}
        Me.TwitchGroupBox3.Controls.Add(Me.ListBox2)
        Me.TwitchGroupBox3.Cursor = System.Windows.Forms.Cursors.Default
        Me.TwitchGroupBox3.Customization = ""
        Me.TwitchGroupBox3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TwitchGroupBox3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.TwitchGroupBox3.Image = Nothing
        Me.TwitchGroupBox3.Location = New System.Drawing.Point(3, 3)
        Me.TwitchGroupBox3.Movable = True
        Me.TwitchGroupBox3.Name = "TwitchGroupBox3"
        Me.TwitchGroupBox3.NoRounding = False
        Me.TwitchGroupBox3.Sizable = True
        Me.TwitchGroupBox3.Size = New System.Drawing.Size(628, 454)
        Me.TwitchGroupBox3.SmartBounds = True
        Me.TwitchGroupBox3.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.TwitchGroupBox3.TabIndex = 0
        Me.TwitchGroupBox3.Text = "Lista de Mods"
        Me.TwitchGroupBox3.TransparencyKey = System.Drawing.Color.Empty
        Me.TwitchGroupBox3.Transparent = False
        '
        'ListBox2
        '
        Me.ListBox2.BackColor = System.Drawing.SystemColors.InfoText
        Me.ListBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox2.Font = New System.Drawing.Font("Verdana", 12.0!)
        Me.ListBox2.ForeColor = System.Drawing.Color.White
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.ItemHeight = 18
        Me.ListBox2.Location = New System.Drawing.Point(3, 76)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(620, 360)
        Me.ListBox2.TabIndex = 0
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.White
        Me.TabPage3.Controls.Add(Me.TwitchGroupBox1)
        Me.TabPage3.Location = New System.Drawing.Point(119, 4)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(634, 460)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Mods Instalados"
        '
        'TwitchGroupBox1
        '
        Me.TwitchGroupBox1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.TwitchGroupBox1.Colors = New zTn_Minecraft_Mods_Loader.Bloom(-1) {}
        Me.TwitchGroupBox1.Controls.Add(Me.ListBox1)
        Me.TwitchGroupBox1.Controls.Add(Me.TwitchBigButton2)
        Me.TwitchGroupBox1.Controls.Add(Me.TwitchBigButton1)
        Me.TwitchGroupBox1.Controls.Add(Me.TwitchLabel1)
        Me.TwitchGroupBox1.Cursor = System.Windows.Forms.Cursors.Default
        Me.TwitchGroupBox1.Customization = ""
        Me.TwitchGroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TwitchGroupBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.TwitchGroupBox1.Image = Nothing
        Me.TwitchGroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.TwitchGroupBox1.Movable = True
        Me.TwitchGroupBox1.Name = "TwitchGroupBox1"
        Me.TwitchGroupBox1.NoRounding = False
        Me.TwitchGroupBox1.Sizable = True
        Me.TwitchGroupBox1.Size = New System.Drawing.Size(634, 460)
        Me.TwitchGroupBox1.SmartBounds = True
        Me.TwitchGroupBox1.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.TwitchGroupBox1.TabIndex = 0
        Me.TwitchGroupBox1.Text = "Mods Instalados em: "
        Me.TwitchGroupBox1.TransparencyKey = System.Drawing.Color.Empty
        Me.TwitchGroupBox1.Transparent = False
        '
        'ListBox1
        '
        Me.ListBox1.BackColor = System.Drawing.Color.Gray
        Me.ListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox1.ForeColor = System.Drawing.Color.White
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Items.AddRange(New Object() {"Mod1.Jaer", "Mod2.Jar"})
        Me.ListBox1.Location = New System.Drawing.Point(27, 38)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(599, 377)
        Me.ListBox1.TabIndex = 2
        '
        'TwitchBigButton2
        '
        Me.TwitchBigButton2.BackColor = System.Drawing.Color.Transparent
        Me.TwitchBigButton2.Colors = New zTn_Minecraft_Mods_Loader.Bloom(-1) {}
        Me.TwitchBigButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TwitchBigButton2.Customization = ""
        Me.TwitchBigButton2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.TwitchBigButton2.Image = Nothing
        Me.TwitchBigButton2.Location = New System.Drawing.Point(250, 422)
        Me.TwitchBigButton2.Name = "TwitchBigButton2"
        Me.TwitchBigButton2.NoRounding = False
        Me.TwitchBigButton2.Size = New System.Drawing.Size(131, 30)
        Me.TwitchBigButton2.TabIndex = 3
        Me.TwitchBigButton2.Tag = "black"
        Me.TwitchBigButton2.Text = "Atualizar Lista"
        Me.TwitchBigButton2.Transparent = True
        Me.TwitchBigButton2.twDoesTurnPurple = False
        Me.TwitchBigButton2.twStarred = False
        Me.TwitchBigButton2.twTabPage = Nothing
        Me.TwitchBigButton2.twTabPageNumber = 1
        '
        'TwitchBigButton1
        '
        Me.TwitchBigButton1.BackColor = System.Drawing.Color.Transparent
        Me.TwitchBigButton1.Colors = New zTn_Minecraft_Mods_Loader.Bloom(-1) {}
        Me.TwitchBigButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TwitchBigButton1.Customization = ""
        Me.TwitchBigButton1.Enabled = False
        Me.TwitchBigButton1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.TwitchBigButton1.Image = Nothing
        Me.TwitchBigButton1.Location = New System.Drawing.Point(387, 422)
        Me.TwitchBigButton1.Name = "TwitchBigButton1"
        Me.TwitchBigButton1.NoRounding = False
        Me.TwitchBigButton1.Size = New System.Drawing.Size(159, 30)
        Me.TwitchBigButton1.TabIndex = 1
        Me.TwitchBigButton1.Tag = "black"
        Me.TwitchBigButton1.Text = "Remover Mod"
        Me.TwitchBigButton1.Transparent = True
        Me.TwitchBigButton1.twDoesTurnPurple = False
        Me.TwitchBigButton1.twStarred = False
        Me.TwitchBigButton1.twTabPage = Nothing
        Me.TwitchBigButton1.twTabPageNumber = 1
        '
        'TwitchLabel1
        '
        Me.TwitchLabel1.AutoSize = True
        Me.TwitchLabel1.BackColor = System.Drawing.Color.Transparent
        Me.TwitchLabel1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.TwitchLabel1.Location = New System.Drawing.Point(203, 212)
        Me.TwitchLabel1.Name = "TwitchLabel1"
        Me.TwitchLabel1.Size = New System.Drawing.Size(281, 13)
        Me.TwitchLabel1.TabIndex = 4
        Me.TwitchLabel1.Text = "Não existe nenhum Mod Instalado no momento."
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.White
        Me.TabPage4.Location = New System.Drawing.Point(119, 4)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(634, 460)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Settings"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(757, 498)
        Me.Controls.Add(Me.TwitchTheme1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximumSize = New System.Drawing.Size(757, 498)
        Me.MinimumSize = New System.Drawing.Size(757, 498)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "zTn Minecraft Mod Loader"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.TwitchTheme1.ResumeLayout(False)
        Me.ChromeTabcontrol1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TwitchGroupBox2.ResumeLayout(False)
        Me.TwitchGroupBox2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TwitchGroupBox3.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TwitchGroupBox1.ResumeLayout(False)
        Me.TwitchGroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TwitchTheme1 As TwitchTheme
    Friend WithEvents ChromeTabcontrol1 As ChromeTabcontrol
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TwitchBigButton1 As TwitchBigButton
    Friend WithEvents TwitchGroupBox1 As TwitchGroupBox
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents AdvantiumCheck1 As AdvantiumCheck
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents TwitchBigButton2 As TwitchBigButton
    Friend WithEvents TwitchLabel1 As TwitchLabel
    Friend WithEvents TwitchGroupBox2 As TwitchGroupBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TwitchLabel2 As TwitchLabel
    Friend WithEvents Timer1 As Timer
    Friend WithEvents TwitchGroupBox3 As TwitchGroupBox
    Friend WithEvents ListBox2 As ListBox
End Class
